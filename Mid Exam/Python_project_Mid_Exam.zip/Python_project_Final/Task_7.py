import statistics

numbers = list(map(int, input("Enter the numbers (space-separated): ").split()))


mean = statistics.mean(numbers)
median = statistics.median(numbers)
try:
    mode = statistics.mode(numbers)
except statistics.StatisticsError:
    mode = "No unique mode"

print(f"Mean: {mean}")
print(f"Median: {median}")
print(f"Mode: {mode}")
