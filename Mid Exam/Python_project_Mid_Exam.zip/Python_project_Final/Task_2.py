user_input = input("Enter something: ")
print("Data type of input is:", type(user_input))
