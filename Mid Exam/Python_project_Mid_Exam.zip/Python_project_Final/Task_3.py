
expression = input("Enter an arithmetic expression (e.g., 3*(2+5)): ")
result = eval(expression)
print("Result of the expression:", result)

