input_string = input("Enter a string: ")
reversed_string = input_string[::-1]
print("Reversed String:", reversed_string)
