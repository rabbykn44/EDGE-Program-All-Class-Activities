
set1 = set(input("Enter elements for first set (comma separated): ").split(","))
set2 = set(input("Enter elements for second set (comma separated): ").split(","))

union_set = set1.union(set2)
intersection_set = set1.intersection(set2)

print("Union of the sets:", union_set)
print("Intersection of the sets:", intersection_set)
